#! /bin/sh

clear

python3 -m programy.clients.polling.telegram.client --config  ../../config/xnix/config.telegram.yaml --cformat yaml --logging ../../config/xnix/logging.yaml

