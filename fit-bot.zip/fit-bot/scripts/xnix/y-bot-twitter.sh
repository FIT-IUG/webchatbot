#! /bin/sh

clear


python3 -m programy.clients.polling.twitter.client --config  ../../config/xnix/config.twitter.yaml --cformat yaml --logging ../../config/xnix/logging.yaml

