#! /bin/sh

clear


python3 -m programy.clients.events.tcpsocket.client --config  ../../config/xnix/config.socket.yaml --cformat yaml --logging ../../config/xnix/logging.yaml

