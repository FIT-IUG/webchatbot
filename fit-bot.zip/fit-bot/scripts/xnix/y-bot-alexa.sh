#! /bin/sh

clear


python3 -m programy.clients.restful.flask.alexa.client --config ../../config/xnix/config.alexa.yaml --cformat yaml --logging ../../config/xnix/logging.yaml

