#! /bin/sh

clear


python3 -m programy.clients.polling.xmpp.client --config  ../../config/xnix/config.xmpp.yaml --cformat yaml --logging ../../config/xnix/logging.yaml

