#! /bin/sh

clear


python3 -m programy.clients.embed.client ../../config/xnix/config.console.yaml



