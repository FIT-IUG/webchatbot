Y-Bot is my bot, its the bot I wanted to develop from the start and will grow over time

The intention is to create a great core bot with an exciting personality that has a good
core general knowledge and then to create suite of extended grammars for different purposes

I have a background in Energy, Finance, Telecoms and Gaming and therefore feel I have a
pretty good grasp of the types of questions a bot would ask and how they should be responded to

The ultimate intention is to create a series of Y-Bot tailored to specific industries



